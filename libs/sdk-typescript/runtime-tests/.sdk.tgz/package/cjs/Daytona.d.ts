import { SandboxVolume } from '@daytona/api-client';
import { AxiosInstance } from 'axios';
import { Image } from './Image';
import { Sandbox, PaginatedSandboxes } from './Sandbox';
import { SnapshotService } from './Snapshot';
import { VolumeService } from './Volume';
export declare const CODE_TOOLBOX_LANGUAGE_LABEL = "code-toolbox-language";
/**
 * Represents a volume mount for a Sandbox.
 *
 * @interface
 * @property {string} volumeId - ID of the Volume to mount
 * @property {string} mountPath - Path on the Sandbox to mount the Volume
 */
export interface VolumeMount extends SandboxVolume {
    volumeId: string;
    mountPath: string;
}
/**
 * Configuration options for initializing the Daytona client.
 *
 * @interface
 * @property {string} apiKey - API key for authentication with the Daytona API
 * @property {string} jwtToken - JWT token for authentication with the Daytona API. If not set, it must be provided
 * via the environment variable `DAYTONA_JWT_TOKEN`, or an API key must be provided instead.
 * @property {string} organizationId - Organization ID used for JWT-based authentication. Required if a JWT token
 * is provided, and must be set either here or in the environment variable `DAYTONA_ORGANIZATION_ID`.
 * @property {string} apiUrl - URL of the Daytona API. Defaults to 'https://app.daytona.io/api'
 * if not set here and not set in environment variable DAYTONA_API_URL.
 * @property {string} target - Target location for Sandboxes
 * @property {boolean} otelEnabled - OpenTelemetry tracing enabled.
 * If set, all SDK operations will be traced.
 *
 * @example
 * const config: DaytonaConfig = {
 *     apiKey: "your-api-key",
 *     apiUrl: "https://your-api.com",
 *     target: "us"
 * };
 * const daytona = new Daytona(config);
 */
export interface DaytonaConfig {
    /** API key for authentication with the Daytona API */
    apiKey?: string;
    /** JWT token for authentication with the Daytona API */
    jwtToken?: string;
    /** Organization ID for authentication with the Daytona API */
    organizationId?: string;
    /** URL of the Daytona API.
     */
    apiUrl?: string;
    /**
     * @deprecated Use `apiUrl` instead. This property will be removed in future versions.
     */
    serverUrl?: string;
    /** Target environment for sandboxes */
    target?: string;
    /** Configuration for experimental features */
    _experimental?: Record<string, any>;
}
/**
 * Supported programming languages for code execution
 *
 * Python is used as the default sandbox language when no language is explicitly specified.
 */
export declare enum CodeLanguage {
    PYTHON = "python",
    TYPESCRIPT = "typescript",
    JAVASCRIPT = "javascript"
}
/**
 * Resource allocation for a Sandbox.
 *
 * @interface
 * @property {number} [cpu] - CPU allocation for the Sandbox in cores
 * @property {number} [gpu] - GPU allocation for the Sandbox in units
 * @property {number} [memory] - Memory allocation for the Sandbox in GiB
 * @property {number} [disk] - Disk space allocation for the Sandbox in GiB
 *
 * @example
 * const resources: SandboxResources = {
 *     cpu: 2,
 *     memory: 4,  // 4GiB RAM
 *     disk: 20    // 20GiB disk
 * };
 */
export interface Resources {
    /** CPU allocation for the Sandbox */
    cpu?: number;
    /** GPU allocation for the Sandbox */
    gpu?: number;
    /** Memory allocation for the Sandbox in GiB */
    memory?: number;
    /** Disk space allocation for the Sandbox in GiB */
    disk?: number;
}
/**
 * Base parameters for creating a new Sandbox.
 *
 * @interface
 * @property {string} [user] - Optional os user to use for the Sandbox
 * @property {CodeLanguage | string} [language] - Programming language for direct code execution. Defaults to "python" if not specified.
 * @property {Record<string, string>} [envVars] - Optional environment variables to set in the Sandbox
 * @property {Record<string, string>} [labels] - Sandbox labels
 * @property {boolean} [public] - Is the Sandbox port preview public
 * @property {number} [autoStopInterval] - Auto-stop interval in minutes (0 means disabled). Default is 15 minutes.
 * @property {number} [autoArchiveInterval] - Auto-archive interval in minutes (0 means the maximum interval will be used). Default is 7 days.
 * @property {number} [autoDeleteInterval] - Auto-delete interval in minutes (negative value means disabled, 0 means delete immediately upon stopping). By default, auto-delete is disabled.
 * @property {VolumeMount[]} [volumes] - Optional array of volumes to mount to the Sandbox
 * @property {boolean} [networkBlockAll] - Whether to block all network access for the Sandbox
 * @property {string} [networkAllowList] - Comma-separated list of allowed CIDR network addresses for the Sandbox
 * @property {boolean} [ephemeral] - Whether the Sandbox should be ephemeral. If true, autoDeleteInterval will be set to 0.
 */
export type CreateSandboxBaseParams = {
    name?: string;
    user?: string;
    language?: CodeLanguage | string;
    envVars?: Record<string, string>;
    labels?: Record<string, string>;
    public?: boolean;
    autoStopInterval?: number;
    autoArchiveInterval?: number;
    autoDeleteInterval?: number;
    volumes?: VolumeMount[];
    networkBlockAll?: boolean;
    networkAllowList?: string;
    ephemeral?: boolean;
};
/**
 * Parameters for creating a new Sandbox.
 *
 * @interface
 * @property {string | Image} [image] - Custom Docker image to use for the Sandbox. If an Image object is provided,
 * the image will be dynamically built.
 * @property {Resources} [resources] - Resource allocation for the Sandbox. If not provided, sandbox will
 * have default resources.
 */
export type CreateSandboxFromImageParams = CreateSandboxBaseParams & {
    image: string | Image;
    resources?: Resources;
};
/**
 * Parameters for creating a new Sandbox from a snapshot.
 *
 * @interface
 * @property {string} [snapshot] - Name of the snapshot to use for the Sandbox.
 */
export type CreateSandboxFromSnapshotParams = CreateSandboxBaseParams & {
    snapshot?: string;
};
/**
 * Main class for interacting with the Daytona API.
 * Provides methods for creating, managing, and interacting with Daytona Sandboxes.
 * Can be initialized either with explicit configuration or using environment variables.
 *
 * @property {VolumeService} volume - Service for managing Daytona Volumes
 * @property {SnapshotService} snapshot - Service for managing Daytona Snapshots
 *
 * @example
 * // Using environment variables
 * // Uses DAYTONA_API_KEY, DAYTONA_API_URL, DAYTONA_TARGET
 * const daytona = new Daytona();
 * const sandbox = await daytona.create();
 *
 * @example
 * // Using explicit configuration
 * const config: DaytonaConfig = {
 *     apiKey: "your-api-key",
 *     apiUrl: "https://your-api.com",
 *     target: "us"
 * };
 * const daytona = new Daytona(config);
 *
 * @example
 * // Disposes daytona and flushes traces when done
 * await using daytona = new Daytona({
 *   otelEnabled: true,
 * });
 * @class
 */
export declare class Daytona implements AsyncDisposable {
    private readonly clientConfig;
    private readonly sandboxApi;
    private readonly objectStorageApi;
    private readonly configApi;
    private readonly target?;
    private readonly apiKey?;
    private readonly jwtToken?;
    private readonly organizationId?;
    private readonly apiUrl;
    private otelSdk?;
    readonly volume: VolumeService;
    readonly snapshot: SnapshotService;
    /**
     * Creates a new Daytona client instance.
     *
     * @param {DaytonaConfig} [config] - Configuration options
     * @throws {DaytonaAuthenticationError} When no credentials are provided (neither API key nor JWT token)
     * @throws {DaytonaAuthenticationError} When JWT token is provided without an organization ID
     */
    constructor(config?: DaytonaConfig);
    [Symbol.asyncDispose](): Promise<void>;
    /**
     * Creates Sandboxes from specified or default snapshot. You can specify various parameters,
     * including language, image, environment variables, and volumes.
     *
     * @param {CreateSandboxFromSnapshotParams} [params] - Parameters for Sandbox creation from snapshot
     * @param {object} [options] - Options for the create operation
     * @param {number} [options.timeout] - Timeout in seconds (0 means no timeout, default is 60)
     * @returns {Promise<Sandbox>} The created Sandbox instance
     *
     * @example
     * const sandbox = await daytona.create();
     *
     * @example
     * // Create a custom sandbox
     * const params: CreateSandboxFromSnapshotParams = {
     *     language: 'typescript',
     *     snapshot: 'my-snapshot-id',
     *     envVars: {
     *         NODE_ENV: 'development',
     *         DEBUG: 'true'
     *     },
     *     autoStopInterval: 60,
     *     autoArchiveInterval: 60,
     *     autoDeleteInterval: 120
     * };
     * const sandbox = await daytona.create(params, { timeout: 100 });
     */
    create(params?: CreateSandboxFromSnapshotParams, options?: {
        timeout?: number;
    }): Promise<Sandbox>;
    /**
     * Creates Sandboxes from specified image available on some registry or declarative Daytona Image. You can specify various parameters,
     * including resources, language, image, environment variables, and volumes. Daytona creates snapshot from
     * provided image and uses it to create Sandbox.
     *
     * @param {CreateSandboxFromImageParams} [params] - Parameters for Sandbox creation from image
     * @param {object} [options] - Options for the create operation
     * @param {number} [options.timeout] - Timeout in seconds (0 means no timeout, default is 60)
     * @param {function} [options.onSnapshotCreateLogs] - Callback function to handle snapshot creation logs.
     * @returns {Promise<Sandbox>} The created Sandbox instance
     *
     * @example
     * const sandbox = await daytona.create({ image: 'debian:12.9' }, { timeout: 90, onSnapshotCreateLogs: console.log });
     *
     * @example
     * // Create a custom sandbox
     * const image = Image.base('alpine:3.18').pipInstall('numpy');
     * const params: CreateSandboxFromImageParams = {
     *     language: 'typescript',
     *     image,
     *     envVars: {
     *         NODE_ENV: 'development',
     *         DEBUG: 'true'
     *     },
     *     resources: {
     *         cpu: 2,
     *         memory: 4 // 4GB RAM
     *     },
     *     autoStopInterval: 60,
     *     autoArchiveInterval: 60,
     *     autoDeleteInterval: 120
     * };
     * const sandbox = await daytona.create(params, { timeout: 100, onSnapshotCreateLogs: console.log });
     */
    create(params?: CreateSandboxFromImageParams, options?: {
        onSnapshotCreateLogs?: (chunk: string) => void;
        timeout?: number;
    }): Promise<Sandbox>;
    /**
     * Gets a Sandbox by its ID or name.
     *
     * @param {string} sandboxIdOrName - The ID or name of the Sandbox to retrieve
     * @returns {Promise<Sandbox>} The Sandbox
     *
     * @example
     * const sandbox = await daytona.get('my-sandbox-id-or-name');
     * console.log(`Sandbox state: ${sandbox.state}`);
     */
    get(sandboxIdOrName: string): Promise<Sandbox>;
    /**
     * Returns paginated list of Sandboxes filtered by labels.
     *
     * @param {Record<string, string>} [labels] - Labels to filter Sandboxes
     * @param {number} [page] - Page number for pagination (starting from 1)
     * @param {number} [limit] - Maximum number of items per page
     * @returns {Promise<PaginatedSandboxes>} Paginated list of Sandboxes that match the labels.
     *
     * @example
     * const result = await daytona.list({ 'my-label': 'my-value' }, 2, 10);
     * for (const sandbox of result.items) {
     *     console.log(`${sandbox.id}: ${sandbox.state}`);
     * }
     */
    list(labels?: Record<string, string>, page?: number, limit?: number): Promise<PaginatedSandboxes>;
    /**
     * Starts a Sandbox and waits for it to be ready.
     *
     * @param {Sandbox} sandbox - The Sandbox to start
     * @param {number} [timeout] - Optional timeout in seconds (0 means no timeout)
     * @returns {Promise<void>}
     *
     * @example
     * const sandbox = await daytona.get('my-sandbox-id');
     * // Wait up to 60 seconds for the sandbox to start
     * await daytona.start(sandbox, 60);
     */
    start(sandbox: Sandbox, timeout?: number): Promise<void>;
    /**
     * Stops a Sandbox.
     *
     * @param {Sandbox} sandbox - The Sandbox to stop
     * @returns {Promise<void>}
     *
     * @example
     * const sandbox = await daytona.get('my-sandbox-id');
     * await daytona.stop(sandbox);
     */
    stop(sandbox: Sandbox): Promise<void>;
    /**
     * Forks a Sandbox, creating a new Sandbox with an identical filesystem.
     *
     * @param {Sandbox} sandbox - The Sandbox to fork
     * @param {object} [params] - Fork parameters
     * @param {string} [params.name] - Optional name for the forked Sandbox
     * @param {number} [timeout] - Timeout in seconds (0 means no timeout, default is 60)
     * @returns {Promise<Sandbox>} The forked Sandbox
     *
     * @example
     * const sandbox = await daytona.get('my-sandbox-id');
     * const forked = await daytona._experimental_fork(sandbox, { name: 'my-fork' });
     * console.log(`Forked sandbox: ${forked.id}`);
     */
    _experimental_fork(sandbox: Sandbox, params?: {
        name?: string;
    }, timeout?: number): Promise<Sandbox>;
    /**
     * Deletes a Sandbox.
     *
     * @param {Sandbox} sandbox - The Sandbox to delete
     * @param {number} timeout - Timeout in seconds (0 means no timeout, default is 60)
     * @returns {Promise<void>}
     *
     * @example
     * const sandbox = await daytona.get('my-sandbox-id');
     * await daytona.delete(sandbox);
     */
    delete(sandbox: Sandbox, timeout?: number): Promise<void>;
    /**
     * @hidden
     */
    static createAxiosInstance(): AxiosInstance;
}
//# sourceMappingURL=Daytona.d.ts.map