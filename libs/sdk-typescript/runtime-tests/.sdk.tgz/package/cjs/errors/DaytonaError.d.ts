/**
 * @module Errors
 */
import { AxiosError, AxiosHeaders } from 'axios';
export type ResponseHeaders = InstanceType<typeof AxiosHeaders>;
/**
 * Base error for Daytona SDK.
 *
 * @example
 * ```ts
 * try {
 *   await daytona.get('missing-sandbox')
 * } catch (error) {
 *   if (error instanceof DaytonaError) {
 *     console.log(error.statusCode)
 *     console.log(error.errorCode)
 *     console.log(error.message)
 *   }
 * }
 * ```
 */
export declare class DaytonaError extends Error {
    /** HTTP status code if available */
    statusCode?: number;
    /** Machine-readable error code if available */
    errorCode?: string;
    /** Response headers if available */
    headers?: ResponseHeaders;
    constructor(message: string, statusCode?: number, headers?: ResponseHeaders, errorCode?: string);
}
/**
 * Error thrown when a resource is not found (HTTP 404).
 *
 * @example
 * ```ts
 * try {
 *   await sandbox.fs.downloadFile('/workspace/missing.txt')
 * } catch (error) {
 *   if (error instanceof DaytonaNotFoundError) {
 *     console.log(error.statusCode)
 *   }
 * }
 * ```
 */
export declare class DaytonaNotFoundError extends DaytonaError {
}
/**
 * Error thrown when rate limit is exceeded.
 *
 * @example
 * ```ts
 * try {
 *   await daytona.list()
 * } catch (error) {
 *   if (error instanceof DaytonaRateLimitError) {
 *     console.log(error.errorCode)
 *   }
 * }
 * ```
 */
export declare class DaytonaRateLimitError extends DaytonaError {
}
/**
 * Error thrown when authentication fails (HTTP 401).
 *
 * @example
 * ```ts
 * try {
 *   await daytona.list()
 * } catch (error) {
 *   if (error instanceof DaytonaAuthenticationError) {
 *     console.log(error.statusCode)
 *   }
 * }
 * ```
 */
export declare class DaytonaAuthenticationError extends DaytonaError {
}
/**
 * Error thrown when the request is forbidden (HTTP 403).
 *
 * @example
 * ```ts
 * try {
 *   await daytona.get('sandbox-without-access')
 * } catch (error) {
 *   if (error instanceof DaytonaAuthorizationError) {
 *     console.log(error.message)
 *   }
 * }
 * ```
 */
export declare class DaytonaAuthorizationError extends DaytonaError {
}
/**
 * Error thrown when a resource conflict occurs (HTTP 409).
 *
 * @example
 * ```ts
 * try {
 *   await daytona.create({ name: 'existing-sandbox' })
 * } catch (error) {
 *   if (error instanceof DaytonaConflictError) {
 *     console.log(error.errorCode)
 *   }
 * }
 * ```
 */
export declare class DaytonaConflictError extends DaytonaError {
}
/**
 * Error thrown when input validation fails (HTTP 400 or client-side validation).
 *
 * @example
 * ```ts
 * try {
 *   Image.debianSlim('3.8' as never)
 * } catch (error) {
 *   if (error instanceof DaytonaValidationError) {
 *     console.log(error.message)
 *   }
 * }
 * ```
 */
export declare class DaytonaValidationError extends DaytonaError {
}
/**
 * Error thrown when a timeout occurs.
 *
 * @example
 * ```ts
 * try {
 *   await sandbox.waitUntilStarted(1)
 * } catch (error) {
 *   if (error instanceof DaytonaTimeoutError) {
 *     console.log(error.message)
 *   }
 * }
 * ```
 */
export declare class DaytonaTimeoutError extends DaytonaError {
}
/**
 * Error thrown when a network connection fails.
 *
 * @example
 * ```ts
 * try {
 *   await ptyHandle.waitForConnection()
 * } catch (error) {
 *   if (error instanceof DaytonaConnectionError) {
 *     console.log(error.message)
 *   }
 * }
 * ```
 */
export declare class DaytonaConnectionError extends DaytonaError {
}
/**
 * Maps an HTTP status code to the corresponding Daytona error class.
 */
export declare function errorClassFromStatusCode(statusCode?: number): typeof DaytonaError;
/**
 * Creates the appropriate Daytona error subclass from structured error metadata.
 */
export declare function createDaytonaError(message: string, statusCode?: number, headers?: ResponseHeaders, errorCode?: string): DaytonaError;
/**
 * Creates the appropriate Daytona error subclass from an Axios error.
 */
export declare function createAxiosDaytonaError(error: AxiosError): DaytonaError;
//# sourceMappingURL=DaytonaError.d.ts.map