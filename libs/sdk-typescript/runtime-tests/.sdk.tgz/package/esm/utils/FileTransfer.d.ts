import type { DownloadMetadata } from '../FileSystem.js';
/**
 * Safely aborts a stream
 */
export declare function abortStream(stream: any): void;
/**
 * Normalizes response data to extract the actual stream
 */
export declare function normalizeResponseStream(responseData: any): any;
/**
 * Processes multipart response using busboy (Node.js path)
 */
export declare function processDownloadFilesResponseWithBusboy(stream: any, headers: Record<string, string>, metadataMap: Map<string, DownloadMetadata>, onFileStream?: (source: string, fileStream: any) => void): Promise<void>;
export declare function processDownloadFilesResponseWithBuffered(stream: any, headers: Record<string, string>, metadataMap: Map<string, DownloadMetadata>): Promise<void>;
//# sourceMappingURL=FileTransfer.d.ts.map