import type { Chart } from './Charts.js';
/**
 * Artifacts from the command execution.
 *
 * @interface
 * @property stdout - Standard output from the command, same as `result` in `ExecuteResponse`
 * @property charts - List of chart metadata from matplotlib
 */
export interface ExecutionArtifacts {
    stdout: string;
    charts?: Chart[];
}
/**
 * Response from the command execution.
 *
 * @interface
 * @property exitCode - The exit code from the command execution
 * @property result - The output from the command execution
 * @property artifacts - Artifacts from the command execution
 */
export interface ExecuteResponse {
    exitCode: number;
    result: string;
    artifacts?: ExecutionArtifacts;
}
//# sourceMappingURL=ExecuteResponse.d.ts.map